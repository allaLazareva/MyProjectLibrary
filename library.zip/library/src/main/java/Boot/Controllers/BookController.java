package Boot.Controllers;

import Boot.Models.Book;
import Boot.Models.Person;
import Boot.Services.BooksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Controller
@RequestMapping("/book")
public class BookController {
    private final BooksService booksService;


    @Autowired
    public BookController(BooksService booksService) {
        this.booksService = booksService;

    }


    @PostMapping
    public ResponseEntity<HttpStatus> saveBook(@RequestBody Book book) {
        booksService.saveBook(book);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @GetMapping("/{id}")
    @ResponseBody
    public Book findBookById(@PathVariable("id") int id){
        return booksService.findById(id);
    }

    @GetMapping
    @ResponseBody
    public List<Book> findAll(){
        return booksService.findAll();
    }

    @GetMapping("/author/{authorName}")
    @ResponseBody
    public List<Book> findBookByAuthor(@PathVariable("authorName") String authorName){
        return booksService.findBookByAuthor(authorName);
    }


    // НЕ РАБОТАЕТ!!!!!!!!!!!!!!!!!!
    @DeleteMapping
    public ResponseEntity<HttpStatus> deleteBook(@RequestBody Book book){
        booksService.delete(book);
        return ResponseEntity.ok(HttpStatus.OK);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteBookById(@PathVariable("id") int id){
        booksService.deleteById(id);
        return ResponseEntity.ok(HttpStatus.OK);
    }


    // Изменяет для книги человека, но только СОЗДАЁТ
    // нового человека по полю name, с id человека не работает
    @PutMapping("/{id}")
    public ResponseEntity<HttpStatus> updateBooksByPersonName
            (@PathVariable("id") int id, @RequestBody Person person) {
       booksService.updateBooksByPersonsName(id, person);
        return ResponseEntity.ok(HttpStatus.OK);
    }


    @ResponseBody
    @GetMapping("book/{book}")
    public List<Person> findByBooks(@PathVariable("book") String nameOfBook){
        return booksService.findByBooks(nameOfBook);
    }





   //ХОЧУ МЕТОД ЧТОБЫ ИЗМЕНЯЛ id ЧЕЛОВЕКА В КНИГЕ!!!!!!!!!!!!!!!!!!!





}
