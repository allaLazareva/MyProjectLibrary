package Boot.Controllers;

import Boot.DAO.PersonDAO;
import Boot.Models.Book;
import Boot.Models.Person;
import Boot.Services.PeopleService;
import Boot.Util.ErrorResponse;
import Boot.Util.PersonNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/people")
public class PeopleController {
    private final PeopleService peopleService;
    private final PersonDAO personDAO;


    @Autowired
    public PeopleController(PeopleService peopleService, PersonDAO personDAO) {
        this.peopleService = peopleService;
        this.personDAO = personDAO;
    }


    @ResponseBody
    @GetMapping()
    public List<Person> getPeople() {
        personDAO.testNPlus1();
        return peopleService.findAll();

    }

    @ResponseBody
    @GetMapping("/{id}")
    public Person getPerson(@PathVariable("id") Integer id) {
        return peopleService.findById(id);
    }




    @ResponseBody
    @GetMapping("/name/{name}")
    public List<Person> getPersonByName(@PathVariable("name") String nameOfPerson) {
        return peopleService.findByName(nameOfPerson);
    }



    @PostMapping
    public ResponseEntity<HttpStatus> save(@RequestBody Person person) {
        peopleService.savePerson(person);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    // НЕ РАБОТАЕТ!!!!!!!!!!!!!!!!!! ПОТОМУ ЧТО удаление по имени не есть уникальным????????
    @DeleteMapping
    public ResponseEntity<HttpStatus> delete(@RequestBody Person person) {
        peopleService.deletePerson(person);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteById(@PathVariable("id") int id) {
        peopleService.deletePersonById(id);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @ExceptionHandler
    private ResponseEntity<ErrorResponse> handlerException(PersonNotFoundException e){
        ErrorResponse errorResponse=new ErrorResponse("Person " +
                "with this id was not found");
    return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);}


    }











