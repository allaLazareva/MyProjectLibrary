package Boot.DAO;

import Boot.Models.Book;
import Boot.Models.Person;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
public class PersonDAO {
   private final EntityManager entityManager;

@Autowired
    public PersonDAO(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Transactional(readOnly = true)
    public void testNPlus1(){
        Session session=entityManager.unwrap(Session.class);
        Set<Person> people=new HashSet<>(session.createQuery("select p from Person p LEFT JOIN FETCH p.books")
                .getResultList());

        for (Person person:people             ) {
            System.out.println("Person "+person.getName()+"read "+person.getBooks());
        }
    }



}
