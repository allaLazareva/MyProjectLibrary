package Boot.Models;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.validator.constraints.UniqueElements;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.List;
import java.util.Objects;


@Entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="person")
public class Person {

    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

   @Column(name = "name", unique = true)
   @NotEmpty
   @UniqueElements
   @Size(min=2, max = 100)
    private String name;

   @Column(name="year_of_birth")
   @Min(value = 0)
    private int yearOfBirth;

   @OneToMany(cascade = CascadeType.ALL, mappedBy = "person")
   @JsonManagedReference
    private List<Book> books;

    public Person(String name) {
        this.name = name;
    }

    public Person(int id) {
        this.id = id;
    }

    public Person(String name, int yearOfBirth) {
        this.name = name;
        this.yearOfBirth = yearOfBirth;
    }

    public Person(String name, int yearOfBirth, List<Book> books) {
        this.name = name;
        this.yearOfBirth = yearOfBirth;
        this.books = books;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return id == person.id && yearOfBirth == person.yearOfBirth && Objects.equals(name, person.name) && Objects.equals(books, person.books);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, yearOfBirth, books);
    }
}
