package Boot.Repositiries;

import Boot.Models.Book;
import Boot.Models.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BooksRepository extends JpaRepository<Book, Integer> {


    List<Book> findBookByAuthor(String authorName);



    @Query(value = "select b.person from Book b where b.name=?1" )
    List<Person> findByBooks(String nameOfBook);


}
