package Boot.Services;

import Boot.Models.Book;
import Boot.Models.Person;
import Boot.Repositiries.BooksRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class BooksService {
    private final BooksRepository booksRepository;

    @Autowired
    public BooksService(BooksRepository booksRepository) {
        this.booksRepository = booksRepository;
    }

    @Transactional
    public void saveBook(Book book){
        booksRepository.save(book);

    }

    public Book findById(int id){
       Optional<Book> book= booksRepository.findById(id);
       return book.orElse(null);
    }

    public List<Book> findAll(){
        return booksRepository.findAll();
    }

    public List<Book> findBookByAuthor(String authorName){
        return booksRepository.findBookByAuthor(authorName);
    }


    @Transactional
    public void delete(Book book){
        booksRepository.delete(book);
    }


    @Transactional
    public void deleteById(int id){
        booksRepository.deleteById(id);
    }

    @Transactional
    public void updateBooksByPersonsName(int idBook, Person person){
        Book book1=booksRepository.findById(idBook).orElse(null);
        book1.setPerson(person);
        booksRepository.save(book1);

    }

    public List<Person> findByBooks(String nameOfBook) {
        return booksRepository.findByBooks(nameOfBook);
    }





}
