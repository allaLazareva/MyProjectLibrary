package Boot.Services;

import Boot.Models.Book;
import Boot.Models.Person;
import Boot.Repositiries.PeopleRepository;
import Boot.Util.PersonNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class PeopleService {

    private final PeopleRepository peopleRepository;

    @Autowired
    public PeopleService(PeopleRepository peopleRepository) {
        this.peopleRepository = peopleRepository;
    }

    @Transactional
    public void savePerson(Person person){
        peopleRepository.save(person);

    }

       public List<Person> findAll(){
        return peopleRepository.findAll();
    }

    public Person findById(int id){
        Optional<Person> person=peopleRepository.findById(id);
        return person.orElseThrow(PersonNotFoundException::new); // throw Exception
    }


    public List<Person> findByName(String nameOfPerson){
        return peopleRepository.findPersonByName(nameOfPerson);
    }

    @Transactional
    public void deletePerson(Person person){
       peopleRepository.delete(person);
    }


    @Transactional
    public void deletePersonById(int id){
        peopleRepository.deleteById(id);
    }



}
