package Boot.Util;

public class PersonNotFoundException extends RuntimeException{
}
